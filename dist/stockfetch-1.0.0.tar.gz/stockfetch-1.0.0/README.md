<div align="center">

# Stockfetch
</div>

**Think Neofetch for stocks**

![RKLB Screenie](./RKLB)

**Notes:**

As with neofetch, this isn't meant to be a representation of L2 data or anything, just a cute, simple CLI for stock nerds to show off.




**Acknowledgments**

Inspired by Neofetch.

Uses Yahoo Finance API for stock data.

> Happy stock tracking!

